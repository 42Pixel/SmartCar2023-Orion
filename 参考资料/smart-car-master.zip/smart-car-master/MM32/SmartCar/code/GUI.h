//
// Created by FLY on 2022/5/7.
//

#ifndef _GUI_H
#define _GUI_H
#include "zf_common_headfile.h"

void GUI_Init(void);
void GUI_Show(void);

#endif //MM32_GUI_H
