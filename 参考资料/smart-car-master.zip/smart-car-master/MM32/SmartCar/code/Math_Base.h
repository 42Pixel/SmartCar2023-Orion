//
// Created by FLY on 2022/5/6.
//

#ifndef MM32_MATH_BASE_H
#define MM32_MATH_BASE_H

float InvSqrt(float x);
float Atan(float v);

#endif //MM32_MATH_BASE_H
